def potencia(op1,op2):
    print ("el resultado de la potencia es: ",op1**op2)

def redondear(op1):
    print ("el resultado redondeado es: ",round(op1))